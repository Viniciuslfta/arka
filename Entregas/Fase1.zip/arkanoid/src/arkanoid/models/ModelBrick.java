/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arkanoid.models;

import java.util.Observable;

/**
 *
 * @author sPeC
 */
public class ModelBrick  extends Observable
{
    
}
