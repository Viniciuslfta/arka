/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arkanoid.views;

import java.util.Observer;

/**
 *
 * @author sPeC
 */
public abstract class ArkanoidView implements Observer{
    abstract public void render();

}
