package arkanoid;

public class AppArkanoid {
 


  public static void main(String[] args) {

      GameEngine game = new GameEngine();
      game.run();
  }

 
}

