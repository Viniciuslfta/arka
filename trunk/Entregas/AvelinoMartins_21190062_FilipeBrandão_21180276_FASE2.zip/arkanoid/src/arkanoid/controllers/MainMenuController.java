/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arkanoid.controllers;

/**
 *
 * @author sPeC
 */
public class MainMenuController implements ArkanoidController{

    @Override
    public void parseInput() {
        
    }

    @Override
    public void update() {
        
    }
    
}
